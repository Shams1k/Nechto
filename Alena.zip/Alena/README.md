# LessonsApp
Команда для создания DbModel и DefaultDbContext:
Scaffold-DbContext 'Data Source=localhost;Initial Catalog=LessonApplication;Integrated security=True' Microsoft.EntityFrameworkCore.SqlServer
 -Context DefaultDbContext -StartupProject ORMDal -Project ORMDal -Force
